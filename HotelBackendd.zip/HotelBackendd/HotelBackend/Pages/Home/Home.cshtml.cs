using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AuctionSystem.Pages.Home
{
    public class HomeModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
