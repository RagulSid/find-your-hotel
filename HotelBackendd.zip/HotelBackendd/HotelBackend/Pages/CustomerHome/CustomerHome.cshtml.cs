using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AuctionSystem.Pages.CustomerHome
{
    public class CustomerHomeModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
